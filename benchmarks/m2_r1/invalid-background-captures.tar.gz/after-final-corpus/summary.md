# M2-R1 v0.1.0 Controlled Baseline

Release binary SHA-256: adbdd7ed6ba49975c5333fea6cff18fad68cdf55553aac080589793582f2c24c

Cases: 29; PASS 25; FAIL 4

| ID | Area | Result |
|---|---|---|
| H01 | HTML | PASS |
| H02 | HTML | FAIL |
| H03 | HTML | PASS |
| H04 | HTML | PASS |
| H05 | HTML | PASS |
| C01 | CSS/paint | FAIL |
| C02 | CSS/paint | PASS |
| C03 | CSS/paint | PASS |
| C04 | CSS/paint | PASS |
| C05 | CSS/paint | PASS |
| C06 | CSS/paint | PASS |
| C07 | CSS/paint | PASS |
| C08 | CSS/paint | PASS |
| I01 | images | PASS |
| J01 | JS/DOM | PASS |
| J02 | JS/DOM | PASS |
| J03 | JS/DOM | PASS |
| J04 | JS/DOM | PASS |
| J05 | JS/DOM | PASS |
| J06 | JS/DOM | PASS |
| J07 | JS/DOM | PASS |
| J08 | JS/DOM | PASS |
| J09 | JS/DOM | PASS |
| J10 | JS/DOM | PASS |
| J11 | JS/async | PASS |
| J12 | JS/async | FAIL |
| J13 | JS/DOM | FAIL |
| J14 | JS/DOM | PASS |
| J15 | JS/DOM | PASS |

These are synthetic local cases, not real-website compatibility scores.
