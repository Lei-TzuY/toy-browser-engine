document.getElementById("out").textContent="EXTERNAL_OK";
