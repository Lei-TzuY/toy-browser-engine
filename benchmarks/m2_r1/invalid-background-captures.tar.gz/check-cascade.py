from pathlib import Path
import hashlib, json, subprocess, sys, time
ROOT=Path("/home/user/ai-scratch/m2-r2-agent-a-20261105")
OUT=Path(__file__).resolve().parent
stage,binary=sys.argv[1],Path(sys.argv[2]).resolve()
rows=json.loads((OUT/"cases.json").read_text())
capture=OUT/stage
capture.mkdir(exist_ok=False)
records=[]
for row in rows:
    fixture=OUT/"fixtures"/(row["id"]+".html")
    image=capture/(row["id"]+".ppm")
    command=[str(binary),"--quiet","--inspect","--size","120x80","--screenshot",str(image),str(fixture)]
    started=time.monotonic()
    proc=subprocess.run(command,capture_output=True,text=True,timeout=15)
    (capture/(row["id"]+".stdout.txt")).write_text(proc.stdout)
    (capture/(row["id"]+".stderr.txt")).write_text(proc.stderr)
    with image.open("rb") as handle:
        assert handle.readline()==b"P6\n"
        assert handle.readline()==b"120 80\n"
        assert handle.readline()==b"255\n"
        pixels=handle.read()
    offset=(5*120+5)*3
    actual=list(pixels[offset:offset+3])
    records.append(dict(id=row["id"],command=command,fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),
                        expected=row["expected"],actual=actual,passed=proc.returncode==0 and actual==row["expected"],
                        exit_code=proc.returncode,elapsed_seconds=round(time.monotonic()-started,4),
                        screenshot_sha256=hashlib.sha256(image.read_bytes()).hexdigest()))
    print(stage,row["id"],actual,"expected",row["expected"],"PASS" if records[-1]["passed"] else "FAIL",flush=True)
report=dict(stage=stage,source_head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),
            source_status=subprocess.check_output(["git","status","--short"],cwd=ROOT,text=True),
            binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
            passed=sum(row["passed"] for row in records),total=len(records),cases=records)
(capture/"results.json").write_text(json.dumps(report,indent=2)+"\n")
print("SUMMARY",report["passed"],report["total"],"binarySHA",report["binary_sha256"],flush=True)
