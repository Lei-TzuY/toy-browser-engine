use fontdue::{Font, FontSettings};
use std::{env,fs};
fn main() {
    for path in env::args().skip(1) {
        let started = std::time::Instant::now();
        match fs::read(&path).ok().and_then(|b| Font::from_bytes(b, FontSettings::default()).ok()) {
            Some(font) => {
                let glyphs: Vec<_> = ['A','\u{03b1}','\u{4e2d}','\u{6587}','\u{6e2c}','\u{8a66}','\u{1f600}'].into_iter()
                    .map(|c|(format!("U+{:X}", c as u32),font.lookup_glyph_index(c),font.metrics(c,28.0).advance_width)).collect();
                println!("{:?}: glyphs={:?}; elapsed_ms={}",path,glyphs,started.elapsed().as_millis());
            }
            None => println!("{:?}: LOAD_FAILED; elapsed_ms={}",path,started.elapsed().as_millis()),
        }
    }
}
