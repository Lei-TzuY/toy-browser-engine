from pathlib import Path
from types import SimpleNamespace
import ctypes as c,hashlib,json,os,subprocess,sys,time
from ctypes import wintypes as w
root=Path(r"C:\Users\User\AppData\Local\Temp\toy-browser-m2r2-b-20261105")
e=root/"evidence";sys.path.insert(0,str(e/"scripts"))
from native_support import WindowsToy
from usability_corpus import PAGES
from PIL import Image
out=e/"native-noinput-render-f330";out.mkdir(exist_ok=False)
u=c.WinDLL("user32",use_last_error=True)
u.GetForegroundWindow.restype=w.HWND
u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)]
u.IsWindowVisible.argtypes=[w.HWND]
u.GetWindowTextW.argtypes=[w.HWND,w.LPWSTR,c.c_int]
u.PostMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM]
cbtype=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM);u.EnumWindows.argtypes=[cbtype,w.LPARAM]
report={"native":True,"mode":"owned native Win32 window render only","os_input_sent":False,"foreground_requests_sent":False,
 "startup_show":"SW_SHOWNOACTIVATE","interactive_gui_gate":"UNVERIFIED","runs":[],"font_candidates":{}}
for name in ["segoeui.ttf","seguisym.ttf","seguiemj.ttf","msyh.ttc","mingliu.ttc"]:
 path=Path(r"C:\Windows\Fonts")/name
 if path.exists():report["font_candidates"][name]={"bytes":path.stat().st_size,"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
env=os.environ.copy()
report["inherited_font_overrides_present"]={key:key in env for key in ["BROWSER_ENGINE_FONT","BROWSER_ENGINE_FALLBACK_FONT"]}
for key in ["BROWSER_ENGINE_FONT","BROWSER_ENGINE_FALLBACK_FONT"]:env.pop(key,None)
for stage,binary,receipt in [
 ("before",e/"bin/browser_engine-c379.exe",e/"native-baseline-binary.json"),
 ("after",e/"bin/browser_engine-f330.exe",e/"native-f330-build.json")]:
 source=json.loads(receipt.read_text(encoding="utf-8"))
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==source["binary_sha256"]
 for route in ["unicode.html","select.html"]:
  case=out/(stage+"-"+route.split(".")[0]);case.mkdir()
  fixture=case/route;fixture.write_bytes(PAGES[route].encode("utf-8"))
  startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=4
  log=(case/"browser.log").open("wb")
  fg_before=u.GetForegroundWindow()
  p=subprocess.Popen([str(binary),"--window","--quiet","--size","800x600",fixture.as_uri()],cwd=case,env=env,
    stdout=log,stderr=subprocess.STDOUT,startupinfo=startup)
  hwnd=None
  try:
   until=time.monotonic()+12
   while time.monotonic()<until and hwnd is None:
    found=[]
    @cbtype
    def cb(h,_):
     pid=w.DWORD();u.GetWindowThreadProcessId(h,c.byref(pid))
     if pid.value==p.pid and u.IsWindowVisible(h):found.append(h)
     return True
    u.EnumWindows(cb,0)
    if found:hwnd=found[0]
    else:time.sleep(.04)
   assert hwnd,"Owned HWND not discovered"
   obj=SimpleNamespace(user=u,gdi=c.WinDLL("gdi32",use_last_error=True),hwnd=hwnd)
   image=case/"owned-client.png";painted=False
   until=time.monotonic()+15
   while time.monotonic()<until:
    WindowsToy.screenshot(obj,image)
    with Image.open(image) as im:
     painted=im.size==(800,668) and im.convert("RGB").getpixel((799,0))==(222,225,230)
    if painted:break
    time.sleep(.05)
   assert painted,"No first painted own-client frame"
   text=c.create_unicode_buffer(8192);u.GetWindowTextW(hwnd,text,len(text))
   row={"stage":stage,"fixture":route,"fixture_sha256":hashlib.sha256(fixture.read_bytes()).hexdigest(),
    "source_revision":source["source_revision"],"binary":str(binary),"binary_sha256":source["binary_sha256"],
    "pid":p.pid,"hwnd":hwnd,"title":text.value,"screenshot":str(image),"screenshot_sha256":hashlib.sha256(image.read_bytes()).hexdigest(),
    "foreground_before":fg_before,"foreground_after_paint":u.GetForegroundWindow(),"capture":"PrintWindow PW_CLIENTONLY"}
   report["runs"].append(row)
  finally:
   if hwnd:u.PostMessageW(hwnd,0x0010,0,0)
   try:p.wait(timeout=8)
   except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=8)
   log.close()
   if report["runs"] and report["runs"][-1].get("pid")==p.pid:report["runs"][-1]["exit_code"]=p.returncode
  print(json.dumps({"stage":stage,"fixture":route,"window_rendered":True,"exit_code":p.returncode}),flush=True)
(out/"receipt.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
print(json.dumps({"receipt":str(out/"receipt.json"),"rendered":len(report["runs"]),"interactive_gui_gate":"UNVERIFIED"}),flush=True)
